'''import sys
no=1
while no<=10:
    print(no)
    no+=1

no=1
while no<=10:
    sys.stdout.write(str(no) + " ")
    no+=1


mydata=["welcome","to","for","loop"]
for i in mydata:
    print(i)

for no in range(10,100):
    print(no)
'''
dict={"harmeet":"22222","aman":"22233"}
for k in dict:
    print(k, ' related to ' , dict[k])