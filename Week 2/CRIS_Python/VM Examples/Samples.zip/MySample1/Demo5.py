'''
no1=input("Enter Number")
if(no1>100):
    print("OK")
elif(no1>90 and no1<99):
    print("DONE")

name=input("Enter Your Name")

if name.startswith("Mr"):
    if name.endswith("sharma"):
        print("Great")
        print("Wel Done Mister")
else:
    if name.endswith("gupta"):
        print("Great")
        print("Mam")
'''
name2=input("Enter Your Name")
if "s" in name2:
    print("Its There")
