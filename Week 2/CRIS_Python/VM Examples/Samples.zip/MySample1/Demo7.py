def MyOwnFunction():
    print("welcome")
    print("To Moduler Programming")

print("Main Step1")
MyOwnFunction()
print("Main Step2")