names=["aman","ravi","komal"]

print(names[0])
print(names[2])

phonebook={"name": "Parul","ph":"2992","name": "Mansi","ph":"2222"}
pb=dict(phonebook)

print(pb["name"])