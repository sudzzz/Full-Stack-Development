print("welcome",10,2)

a,b,c=10,20,30

print(a,b,c)

name=input("Enter Your Name")

if name.startswith("sehra"):
    print("Welcome Admin")
else:
    print("Sorry")

