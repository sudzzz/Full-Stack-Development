
print("welcome")

no1=int(input("Enter No"))
print(no1)

Info="My Name Is %s and I am %d year old"
values=("Harmeet",20)

print(Info % values)
Info2="My Name Is Harmeet"
print(Info2.find("sdsds"))

print(Info2.lower())
print(Info2.replace("is","was"))

