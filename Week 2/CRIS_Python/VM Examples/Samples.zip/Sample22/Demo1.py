from tkinter import *
root=Tk()

root.title("Harmeet Window's in Python")
root.geometry("200x200")

root.mainloop()
