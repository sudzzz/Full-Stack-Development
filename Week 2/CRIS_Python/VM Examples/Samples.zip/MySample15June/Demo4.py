def MyOwnFunction(i,j):
    return (i+j)*2


print("Main Step1")
print(MyOwnFunction(2,9))
print("Main Step2")