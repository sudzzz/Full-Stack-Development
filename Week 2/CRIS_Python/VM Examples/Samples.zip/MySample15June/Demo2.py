def MyOwnFunction():
    print("welcome")
    print("To Moduler Programming")

def MyOwnFunction2(nm):
    print("Hi "  +nm)


print("Main Step1")
MyOwnFunction()
MyOwnFunction2("Harmeet")
print("Main Step2")