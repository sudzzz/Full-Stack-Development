def MyOwnFunction():
    print("welcome")

def MyOwnFunction2(nm):
    print("Hi "  +nm)

def MyOwnFunction3(nm,i,j):
    while i<j:
     print(nm)
     i+=1


print("Main Step1")
MyOwnFunction()
MyOwnFunction2("Harmeet")
MyOwnFunction3("H",2,9)
print("Main Step2")