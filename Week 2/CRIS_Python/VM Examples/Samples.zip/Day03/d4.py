mainvalue=0
x=10
def MyF(x=90):
    #print(mainvalue)
    #mainvalue = 20
    print(x)

MyF(80)
