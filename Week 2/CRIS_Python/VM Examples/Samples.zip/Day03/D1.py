print("A")
def MyOwnFunction():
    print("Welcome")
    print("To modular Programming")

def MyOwnFunction2(nm):
    print("hi" + nm)


MyOwnFunction()
MyOwnFunction2("Aman")
print("B")