def MyFunction(nm,i,j):
    while(i<j):
        print(nm)
        i+=1


MyFunction("*",2,10)
MyFunction(input("Enter Your name"),2,10)
