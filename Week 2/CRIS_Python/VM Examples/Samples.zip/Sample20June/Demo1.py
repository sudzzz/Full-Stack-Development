lst=["India","Ausrtralia",1000]

for lstvalue in lst:
    print(lstvalue)

lst.append("Pakistan")

for lstvalue in lst:
    print(lstvalue)

lst[3]="West Indies"

for lstvalue in lst:
    print(lstvalue)

del lst[2]

for lstvalue in lst:
    print(lstvalue)

