lst1=["India","Ausrtralia"]
lst2=[1000,2000]

lst1=lst1+lst2

for lstvalue in lst1:
    print(lstvalue)
