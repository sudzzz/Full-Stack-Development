#Modules Usage

import Demo4_Import
Demo4_Import.PrintWelcome("Aman")

'''
from Demo4_Import import PrintThanks
PrintThanks()
'''