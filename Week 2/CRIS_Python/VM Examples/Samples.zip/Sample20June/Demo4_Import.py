def PrintWelcome(nm):
    print("Welcome " + nm)

def PrintThanks():
    print("Thanks To You")


