from django.apps import AppConfig


class MyvideolibraryConfig(AppConfig):
    name = 'MyVideoLibrary'
