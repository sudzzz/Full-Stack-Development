from django.apps import AppConfig


class Django19JuneConfig(AppConfig):
    name = 'Django19June'
