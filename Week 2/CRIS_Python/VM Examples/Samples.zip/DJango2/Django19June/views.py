from django.shortcuts import render

# Create your views here.
def index(request):
    pst=Poll.objects.adll()
    t=loader.get_templage

