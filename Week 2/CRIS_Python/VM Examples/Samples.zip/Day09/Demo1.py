from tkinter import *

root=Tk()
root.title("Python's GUI Programming")
root.geometry("200x300")

root.mainloop()