from django.shortcuts import render
from django.Http import HttpResponse
# Create your views here.

def index(request):
    return HttpResponse("Done")