from django.db import models
import MySQLdb



# Create your models here.
