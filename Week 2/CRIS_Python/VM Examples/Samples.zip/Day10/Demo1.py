#Lambda Expressions

def MyFunction(x):
    return x*x

print(MyFunction(int(input("Enter No"))))

#following is lambda expression

lr=lambda x:x*x
print(lr(int(input("Enter No"))))
