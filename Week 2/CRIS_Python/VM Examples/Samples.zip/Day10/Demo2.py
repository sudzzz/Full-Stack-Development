
'''lr2=lambda x:(print(x) or x+4)

lr2(2)'''

lr3=lambda y:(y+4,y*y)
lr3(2)
