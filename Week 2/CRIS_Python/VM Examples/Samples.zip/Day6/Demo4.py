'''import Demo4_Lib

Demo4_Lib.PrintWelcome("Aman")
print("This is main application")'''

from Demo4_Lib import PrintThanks

print("new Way")
PrintThanks()
print("This is main application")