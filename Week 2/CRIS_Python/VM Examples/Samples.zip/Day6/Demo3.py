tup1=("Phy","Chem","Mth")

for tp in tup1:
    print(tp)

tup1[0]="Msc"
for tp in tup1:
    print(tp)
