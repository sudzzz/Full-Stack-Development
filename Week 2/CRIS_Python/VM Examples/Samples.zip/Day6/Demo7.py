def show(nm):
    return("Hi " +nm)

print(show("Aman"))


showL=lambda x:"Hi " + x
print(showL("Parul"))