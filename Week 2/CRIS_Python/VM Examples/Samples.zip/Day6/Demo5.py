no1=int(input("Enter no 1"))
no2=int(input("Enter no 2"))
no3=no1/no2
