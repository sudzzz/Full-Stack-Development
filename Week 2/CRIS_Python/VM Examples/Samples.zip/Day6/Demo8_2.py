lst = [10, 20, 30]
print(lambda x: x%2==0,lst)

print(lambda x: if(x%2==0):"OK",lst)
