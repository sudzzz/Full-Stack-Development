lst1=["India","Australia"]
lst2=[200,300]

lst1=lst1+lst2

for lstvalue in lst1:
    print(lstvalue)