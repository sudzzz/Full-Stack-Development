from django.apps import AppConfig


class VideolibConfig(AppConfig):
    name = 'VideoLib'
