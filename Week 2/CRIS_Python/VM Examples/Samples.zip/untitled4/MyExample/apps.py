from django.apps import AppConfig


class MyexampleConfig(AppConfig):
    name = 'MyExample'
