str="Welcome to python language"
print(str.find(" "))
print(str.find(" ",8))
print(str.split(' '))
print(str.split('to'))

print(str[2])
print(str[2:10])
str="Welcome to python language"
print(str.count(" "))
