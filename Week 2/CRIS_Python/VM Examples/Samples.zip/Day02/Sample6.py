contacts={}

contacts["a"]="aman"
contacts["b"]="rajat"

for f in contacts:
    print(f , contacts[f])


