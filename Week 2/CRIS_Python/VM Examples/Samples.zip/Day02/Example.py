name=[]
age=[]
salj=[]
salf=[]

i=0
while i<2:
    name.append(input("enter name value"))
    age.append(input("enter age value"))
    salj.append(input("enter jan sal value"))
    salf.append(input("enter feb sal value"))
    i+=1

i=0
while i<2:
    print(name[i] + age [i])
    i+=1
