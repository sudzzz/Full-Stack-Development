no1=int(input("Enter Number"))
if(no1>100):
    print("OK")
elif(no1>90 and no1<99):
    print ("Done")

name=input("Enter Name")
if name.startswith("Aman"):
 if name.endswith("sharma"):
  print("Great")
  print("WelDone")
else:
    if name.endswith("verma"):
        print("OK")
        print("Fine")