'''no=1
while no<=10:
    print(no)

    no+=1

import sys
no=1
while no<=10:
    sys.stdout.write(str(no) + " ")
    no+=1

'''
info=["welcome","to","for","loop"]

for s in info:
    print (s)



info2 = ["welcome", "to", "for", "loop"]
res=""
for s in info:
    res+=s
print (res)

