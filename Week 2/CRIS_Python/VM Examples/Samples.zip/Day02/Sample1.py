'''
print("Welcome")
Info="My Name Is %s and I am %d Year Old"
data=("Aman",20)
print(Info % data)
'''
name="My Name Is Khan"
print(name.find("khan"))
names=["aman","rajat","parul"]
print(names[0])








