from django.apps import AppConfig


class MysapConfig(AppConfig):
    name = 'MySAP'
