from tkinter import *

root = Tk()

Label(root, text="India", bg="red", fg="white").pack()
Label(root, text="Australia", bg="green", fg="black").pack()
Label(root, text="Pakistan", bg="blue", fg="white").pack()

mainloop()