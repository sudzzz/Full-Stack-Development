import re

#print(re.split(r'(\m*)','welcome to my world'))
#print(re.split(r'(m*)','welcome to my world'))
print(re.split(r'[a-f]','welcome to my world'))
