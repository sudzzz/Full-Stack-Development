

def myfunction(x):
    return x*x;
print(myfunction(int(input("Enter No"))))

lr1=lambda x:x*x
print(lr1(2))
def myfunction2(x):
    x+=1
    x+=20
    return x*x;

print(myfunction2(int(input("Enter No"))))


