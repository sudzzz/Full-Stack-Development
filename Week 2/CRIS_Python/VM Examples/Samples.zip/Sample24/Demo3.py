
lr2=lambda x:(print(x) or x+4)
print(lr2(22))
print("New One")

lr3=lambda x:(x+4,x*x,x*x*x)
print(lr3(3))
